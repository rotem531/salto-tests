Unicode CLDR locale data from the Intl polyfill v1.2.5
https://github.com/andyearnshaw/Intl.js

zh-CN == zh-Hans-CN
zh-TW == zh-Hant-TW

Those .json files were manually duplicated and renamed since the older language codes are still most frequently used.